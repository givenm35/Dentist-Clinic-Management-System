function hideMessage() {
    document.getElementById("msg").style.display = "none";
};

setTimeout(hideMessage, 2000);